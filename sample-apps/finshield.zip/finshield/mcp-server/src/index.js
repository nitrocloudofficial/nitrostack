#!/usr/bin/env node
const { McpServer } = require("@modelcontextprotocol/sdk/server/mcp.js");
const { StdioServerTransport } = require("@modelcontextprotocol/sdk/server/stdio.js");
const { z } = require("zod");
const path = require("path");
const engine = require(path.join(__dirname, "..", "..", "shared", "engine.js"));

const server = new McpServer({
  name: "finshield",
  version: "1.0.0",
  description:
    "FinShield — an AI financial resilience copilot. Watches for silent leakage, understands income fragility, and produces a crisis playbook the moment things go wrong. Never acts without explicit human approval.",
});

const json = (data) => ({
  content: [{ type: "text", text: JSON.stringify(data, null, 2) }],
});

// In-memory session — a real MCP session is a single conversation, so caching
// the pipeline's intermediate results here avoids recomputing from scratch
// every tool call, mirroring the dependency graph in the problem statement.
const session = {};

// ---------------------------------------------------------------------------
// Resources — mock bank/data feeds
// ---------------------------------------------------------------------------
server.resource(
  "transactions",
  "finshield://data/transactions",
  { description: "Mock bank transaction history (~90 days)", mimeType: "application/json" },
  async (uri) => ({
    contents: [
      {
        uri: uri.href,
        mimeType: "application/json",
        text: JSON.stringify(engine.getTransactions(), null, 2),
      },
    ],
  })
);

server.resource(
  "income-history",
  "finshield://data/income-history",
  { description: "6 months of mock gig/freelance income history", mimeType: "application/json" },
  async (uri) => ({
    contents: [
      {
        uri: uri.href,
        mimeType: "application/json",
        text: JSON.stringify(engine.getIncomeHistory(), null, 2),
      },
    ],
  })
);

server.resource(
  "fee-rules",
  "finshield://data/fee-rules",
  { description: "Reference table of common bank fee types and how to avoid them", mimeType: "application/json" },
  async (uri) => ({
    contents: [
      {
        uri: uri.href,
        mimeType: "application/json",
        text: JSON.stringify(engine.getFeeRules(), null, 2),
      },
    ],
  })
);

server.resource(
  "usage-signals",
  "finshield://data/usage-signals",
  { description: "Mock subscription engagement signals (last-active estimates)", mimeType: "application/json" },
  async (uri) => ({
    contents: [
      {
        uri: uri.href,
        mimeType: "application/json",
        text: JSON.stringify(engine.getUsageSignals(), null, 2),
      },
    ],
  })
);

// ---------------------------------------------------------------------------
// Prompt — advisor persona
// ---------------------------------------------------------------------------
server.prompt(
  "financial-advisor-persona",
  "Shapes FinShield's tone: a plain-spoken, non-judgmental financial advisor, never jargon-heavy, always explaining the 'why' behind a recommendation.",
  {},
  async () => ({
    messages: [
      {
        role: "user",
        content: {
          type: "text",
          text: [
            "You are FinShield, a calm and direct financial advisor.",
            "Rules:",
            "- Explain every flagged leak in one plain-language sentence: what it is and why it's flagged.",
            "- Never use jargon (no 'liquidity', 'delta', 'basis points').",
            "- Be encouraging, not alarmist, even in crisis mode.",
            "- Never say you will cancel, apply, or change anything without the user's explicit approval.",
            "- Always state numbers in concrete terms (₹ amounts, month counts), never vague ranges.",
          ].join("\n"),
        },
      },
    ],
  })
);

// ---------------------------------------------------------------------------
// Tool 1
// ---------------------------------------------------------------------------
server.tool(
  "get_transactions",
  "Fetch the user's mock bank transaction history (~90 days).",
  {},
  async () => json(engine.getTransactions())
);

// ---------------------------------------------------------------------------
// Tool 2
// ---------------------------------------------------------------------------
server.tool(
  "get_income_history",
  "Fetch 6 months of the user's mock income history.",
  {},
  async () => json(engine.getIncomeHistory())
);

// ---------------------------------------------------------------------------
// Tool 3 (depends on 1)
// ---------------------------------------------------------------------------
server.tool(
  "detect_recurring_charges",
  "Analyze transaction history and identify recurring/patterned charges — no manual tagging required. Depends on get_transactions.",
  {},
  async () => {
    session.recurring = engine.detectRecurringCharges();
    return json(session.recurring);
  }
);

// ---------------------------------------------------------------------------
// Tool 4 (depends on 3)
// ---------------------------------------------------------------------------
server.tool(
  "classify_charge",
  "Classify a detected recurring charge as essential, subscription, or recurring_other. Depends on detect_recurring_charges.",
  { merchant: z.string().describe("Merchant name as returned by detect_recurring_charges") },
  async ({ merchant }) => {
    const recurring = session.recurring || engine.detectRecurringCharges();
    const charge = recurring.find((c) => c.merchant === merchant);
    if (!charge) return json({ error: `No recurring charge found for merchant "${merchant}".` });
    return json({ merchant, classification: engine.classifyCharge(charge) });
  }
);

// ---------------------------------------------------------------------------
// Tool 5 (depends on 1)
// ---------------------------------------------------------------------------
server.tool(
  "detect_fee_leaks",
  "Scan transactions for hidden bank fees: forex markup, ATM fees, minimum-balance penalties, late fees. Depends on get_transactions.",
  {},
  async () => {
    session.feeLeaks = engine.detectFeeLeaks();
    return json(session.feeLeaks);
  }
);

// ---------------------------------------------------------------------------
// Tool 6 (depends on 3, 4)
// ---------------------------------------------------------------------------
server.tool(
  "assess_subscription_value",
  "Judge whether each detected subscription is worth keeping, based on usage recency and overlap with similar subscriptions. Depends on detect_recurring_charges and classify_charge.",
  {},
  async () => {
    const recurring = session.recurring || engine.detectRecurringCharges();
    session.subscriptionAssessments = engine.assessSubscriptionValue(recurring);
    return json(session.subscriptionAssessments);
  }
);

// ---------------------------------------------------------------------------
// Tool 7 (depends on 2)
// ---------------------------------------------------------------------------
server.tool(
  "analyze_income_pattern",
  "Classify income as stable or volatile, and identify lean vs. strong months. Depends on get_income_history.",
  {},
  async () => {
    session.incomePattern = engine.analyzeIncomePattern();
    return json(session.incomePattern);
  }
);

// ---------------------------------------------------------------------------
// Tool 8 (depends on 7)
// ---------------------------------------------------------------------------
server.tool(
  "calculate_recommended_buffer",
  "Calculate a recommended savings buffer to smooth over lean-income months. Depends on analyze_income_pattern.",
  {},
  async () => {
    const profile = engine.getUserProfile();
    const essentialMonthly = Object.values(profile.monthlyEssentialExpenses).reduce((s, v) => s + v, 0);
    const incomePattern = session.incomePattern || engine.analyzeIncomePattern();
    session.buffer = engine.calculateRecommendedBuffer(incomePattern, essentialMonthly);
    return json(session.buffer);
  }
);

// ---------------------------------------------------------------------------
// Tool 9 (depends on 5, 6, 7)
// ---------------------------------------------------------------------------
server.tool(
  "calculate_runway",
  "Combine savings, essential expenses, fee leaks, subscriptions, and income stability into a single 'months of runway' figure. Depends on detect_fee_leaks, assess_subscription_value, analyze_income_pattern.",
  {},
  async () => {
    const profile = engine.getUserProfile();
    const essentialMonthly = Object.values(profile.monthlyEssentialExpenses).reduce((s, v) => s + v, 0);
    const feeLeaks = session.feeLeaks || engine.detectFeeLeaks();
    const subs = session.subscriptionAssessments || engine.assessSubscriptionValue();
    const incomePattern = session.incomePattern || engine.analyzeIncomePattern();

    session.runway = engine.calculateRunway({
      currentSavings: profile.currentSavings,
      essentialMonthly,
      feeLeaksMonthlyTotal: feeLeaks.reduce((s, f) => s + f.monthlyAvg, 0),
      subscriptionMonthlyTotal: subs.reduce((s, x) => s + x.monthlyAmount, 0),
      incomeStability: incomePattern.stability,
    });
    return json(session.runway);
  }
);

// ---------------------------------------------------------------------------
// Tool 10 (depends on 6, 8, 9)
// ---------------------------------------------------------------------------
server.tool(
  "generate_health_report",
  "Compile the full financial health report: runway, income stability, leaks, and a plain-language narrative. Depends on assess_subscription_value, calculate_recommended_buffer, calculate_runway.",
  {},
  async () => {
    session.healthReport = engine.generateHealthReport();
    return json(session.healthReport);
  }
);

// ---------------------------------------------------------------------------
// Tool 11 (depends on 10)
// ---------------------------------------------------------------------------
server.tool(
  "trigger_crisis_mode",
  "Simulate a financial shock (e.g. sudden loss of income) and switch FinShield into triage mode. Depends on generate_health_report.",
  {},
  async () => {
    const report = session.healthReport || engine.generateHealthReport();
    session.crisis = engine.triggerCrisisMode(report);
    return json({ mode: session.crisis.mode, triggeredAt: session.crisis.triggeredAt });
  }
);

// ---------------------------------------------------------------------------
// Tool 12 (depends on 6, 10)
// ---------------------------------------------------------------------------
server.tool(
  "prioritize_expenses",
  "Classify every recurring expense into non-negotiable vs. cuttable using existing leak data (nothing recomputed from scratch). Depends on trigger_crisis_mode / generate_health_report.",
  {},
  async () => {
    const report = (session.crisis && session.crisis.baseReport) || session.healthReport || engine.generateHealthReport();
    session.prioritized = engine.prioritizeExpenses(report);
    return json(session.prioritized);
  }
);

// ---------------------------------------------------------------------------
// Tool 13 (depends on 12)
// ---------------------------------------------------------------------------
server.tool(
  "generate_action_plan",
  "Produce a concrete, numbered 30-day survival plan with a new projected runway. Depends on prioritize_expenses.",
  {},
  async () => {
    const report = (session.crisis && session.crisis.baseReport) || session.healthReport || engine.generateHealthReport();
    session.actionPlan = engine.generateActionPlan(report);
    return json(session.actionPlan);
  }
);

// ---------------------------------------------------------------------------
// Tool 14 (depends on 13, REQUIRES human approval)
// ---------------------------------------------------------------------------
server.tool(
  "apply_recommended_cuts",
  "Flag specific subscriptions/fees as cut — but ONLY executes if `approved` is explicitly true. This is the human-in-the-loop gate: never call with approved=true unless the user has actually clicked Allow in their client's Tool Approval prompt.",
  {
    itemIds: z.array(z.string()).describe("IDs of items to cut, e.g. from prioritize_expenses/generate_action_plan (format 'sub:<merchant>' or 'fee:<merchant>')"),
    approved: z.boolean().describe("Must be true only if the human has explicitly approved this action"),
  },
  async ({ itemIds, approved }) => json(engine.applyRecommendedCuts(itemIds, approved))
);

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("FinShield MCP server running on stdio");
}

main().catch((err) => {
  console.error("Fatal error starting FinShield MCP server:", err);
  process.exit(1);
});
