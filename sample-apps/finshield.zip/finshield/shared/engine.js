/**
 * FinShield core engine.
 * Pure functions implementing the 14-tool analytical pipeline described in
 * the FinShield problem statement. Both the MCP server (mcp-server/) and the
 * web app backend (web-app/server/) import this same module so the two
 * surfaces are always in sync.
 */
const fs = require("fs");
const path = require("path");

const DATA_DIR = path.join(__dirname, "data");

// Fixed "as of" date so the mock data always reads as fresh & realistic,
// regardless of which day the app is actually launched.
const TODAY = new Date("2026-07-26T00:00:00Z");

const ESSENTIAL_CATEGORIES = ["rent", "utilities", "insurance", "loan_emi"];
const SUBSCRIPTION_CATEGORIES = [
  "streaming",
  "music",
  "cloud_storage",
  "fitness",
  "productivity_saas",
];

// ---------------------------------------------------------------------------
// Resource loaders (mirrors the MCP "Resources" concept)
// ---------------------------------------------------------------------------
function loadJSON(file) {
  return JSON.parse(fs.readFileSync(path.join(DATA_DIR, file), "utf-8"));
}

function getTransactions() {
  return loadJSON("transactions.json");
}

function getIncomeHistory() {
  return loadJSON("income_history.json");
}

function getFeeRules() {
  return loadJSON("fee_rules.json");
}

function getUsageSignals() {
  return loadJSON("usage_signals.json");
}

function getUserProfile() {
  return loadJSON("user_profile.json");
}

function daysBetween(a, b) {
  return Math.round((b.getTime() - new Date(a).getTime()) / 86400000);
}

// ---------------------------------------------------------------------------
// Tool 3: detect_recurring_charges
// ---------------------------------------------------------------------------
function detectRecurringCharges(transactions = getTransactions()) {
  const groups = {};
  for (const t of transactions) {
    if (t.category === "bank_fee") continue; // fees are handled separately
    const key = t.merchant;
    groups[key] = groups[key] || [];
    groups[key].push(t);
  }

  const recurring = [];
  for (const [merchant, txns] of Object.entries(groups)) {
    if (txns.length < 2) continue;
    const sorted = [...txns].sort((a, b) => new Date(a.date) - new Date(b.date));
    const intervals = [];
    for (let i = 1; i < sorted.length; i++) {
      intervals.push(daysBetween(sorted[i - 1].date, new Date(sorted[i].date)));
    }
    const avgIntervalDays =
      intervals.reduce((s, v) => s + v, 0) / intervals.length;

    // Roughly monthly cadence => recurring
    if (avgIntervalDays >= 18 && avgIntervalDays <= 40) {
      const last = sorted[sorted.length - 1];
      recurring.push({
        merchant,
        category: last.category,
        amount: last.amount,
        occurrences: sorted.length,
        firstDate: sorted[0].date,
        lastDate: last.date,
        avgIntervalDays: Math.round(avgIntervalDays),
      });
    }
  }
  return recurring;
}

// ---------------------------------------------------------------------------
// Tool 4: classify_charge
// ---------------------------------------------------------------------------
function classifyCharge(charge) {
  if (ESSENTIAL_CATEGORIES.includes(charge.category)) return "essential";
  if (SUBSCRIPTION_CATEGORIES.includes(charge.category)) return "subscription";
  return "recurring_other";
}

// ---------------------------------------------------------------------------
// Tool 5: detect_fee_leaks
// ---------------------------------------------------------------------------
function detectFeeLeaks(
  transactions = getTransactions(),
  feeRules = getFeeRules(),
  monthsCovered = 3
) {
  const fees = transactions.filter((t) => t.category === "bank_fee");
  const groups = {};
  for (const f of fees) {
    groups[f.merchant] = groups[f.merchant] || [];
    groups[f.merchant].push(f);
  }

  const matchRule = (merchantName) => {
    const n = merchantName.toLowerCase();
    if (n.includes("atm")) return feeRules.find((r) => r.code === "atm_oon");
    if (n.includes("markup") || n.includes("forex") || n.includes("cross-currency"))
      return feeRules.find((r) => r.code === "forex_markup");
    if (n.includes("minimum balance"))
      return feeRules.find((r) => r.code === "min_balance");
    if (n.includes("late")) return feeRules.find((r) => r.code === "late_fee");
    return null;
  };

  return Object.entries(groups).map(([merchant, txns]) => {
    const totalAmount = txns.reduce((s, t) => s + t.amount, 0);
    const rule = matchRule(merchant);
    return {
      merchant,
      category: "bank_fee",
      occurrences: txns.length,
      totalAmount,
      monthlyAvg: Math.round((totalAmount / monthsCovered) * 100) / 100,
      rule: rule
        ? {
            code: rule.code,
            name: rule.name,
            avoidanceTip: rule.avoidance_tip,
          }
        : null,
    };
  });
}

// ---------------------------------------------------------------------------
// Tool 6: assess_subscription_value
// ---------------------------------------------------------------------------
function assessSubscriptionValue(
  recurringCharges = detectRecurringCharges(),
  usageSignals = getUsageSignals()
) {
  const subs = recurringCharges.filter(
    (c) => classifyCharge(c) === "subscription"
  );

  // find overlapping categories among subscriptions
  const byCategory = {};
  for (const s of subs) {
    byCategory[s.category] = byCategory[s.category] || [];
    byCategory[s.category].push(s.merchant);
  }

  return subs.map((s) => {
    const usage = usageSignals[s.merchant] || { lastActiveDaysAgo: null, note: "" };
    const overlapPeers = (byCategory[s.category] || []).filter(
      (m) => m !== s.merchant
    );

    let status = "keep";
    let reason;

    if (usage.lastActiveDaysAgo !== null && usage.lastActiveDaysAgo >= 45) {
      status = "cancel";
      reason = `Last used ${usage.lastActiveDaysAgo} days ago — ${usage.note.toLowerCase()}.`;
    } else if (overlapPeers.length > 0) {
      status = "question";
      reason = `Overlaps with ${overlapPeers.join(", ")} in the same "${s.category}" category — you may be paying twice for similar value.`;
    } else {
      status = "keep";
      reason = `Actively used (${usage.lastActiveDaysAgo ?? "recently"} day${
        usage.lastActiveDaysAgo === 1 ? "" : "s"
      } ago) — good value for the spend.`;
    }

    return {
      merchant: s.merchant,
      category: s.category,
      monthlyAmount: s.amount,
      lastActiveDaysAgo: usage.lastActiveDaysAgo,
      status,
      reason,
    };
  });
}

// ---------------------------------------------------------------------------
// Tool 7: analyze_income_pattern
// ---------------------------------------------------------------------------
function analyzeIncomePattern(incomeHistory = getIncomeHistory()) {
  const amounts = incomeHistory.map((i) => i.amount);
  const mean = amounts.reduce((s, v) => s + v, 0) / amounts.length;
  const variance =
    amounts.reduce((s, v) => s + (v - mean) ** 2, 0) / amounts.length;
  const stdev = Math.sqrt(variance);
  const cv = stdev / mean;

  const stability = cv < 0.2 ? "stable" : "volatile";
  const leanThreshold = mean * 0.7;
  const strongThreshold = mean * 1.15;

  const leanMonths = incomeHistory.filter((i) => i.amount < leanThreshold);
  const strongMonths = incomeHistory.filter((i) => i.amount > strongThreshold);

  return {
    mean: Math.round(mean),
    stdev: Math.round(stdev),
    coefficientOfVariation: Math.round(cv * 100) / 100,
    stability,
    leanMonths,
    strongMonths,
    history: incomeHistory,
  };
}

// ---------------------------------------------------------------------------
// Tool 8: calculate_recommended_buffer
// ---------------------------------------------------------------------------
function calculateRecommendedBuffer(incomePattern, essentialMonthly) {
  if (incomePattern.leanMonths.length === 0) {
    return {
      recommendedBufferAmount: 0,
      recommendedBufferMonths: 0,
      explanation:
        "Income has been consistent enough that no extra buffer is currently recommended.",
    };
  }

  const avgShortfall =
    incomePattern.leanMonths.reduce(
      (s, m) => s + Math.max(0, essentialMonthly - m.amount),
      0
    ) / incomePattern.leanMonths.length;

  const recommendedBufferAmount = Math.round(
    avgShortfall * incomePattern.leanMonths.length
  );
  const recommendedBufferMonths =
    Math.round((recommendedBufferAmount / essentialMonthly) * 10) / 10;

  return {
    recommendedBufferAmount,
    recommendedBufferMonths,
    explanation: `Based on ${incomePattern.leanMonths.length} lean month(s) in the last ${incomePattern.history.length}, set aside about ${recommendedBufferAmount.toLocaleString(
      "en-IN"
    )} during strong months to cover the gap when income dips.`,
  };
}

// ---------------------------------------------------------------------------
// Tool 9: calculate_runway
// ---------------------------------------------------------------------------
function calculateRunway({
  currentSavings,
  essentialMonthly,
  feeLeaksMonthlyTotal,
  subscriptionMonthlyTotal,
  incomeStability,
}) {
  const totalMonthlyBurn =
    essentialMonthly + feeLeaksMonthlyTotal + subscriptionMonthlyTotal;
  const rawRunwayMonths = currentSavings / totalMonthlyBurn;
  const volatilityDiscount = incomeStability === "volatile" ? 0.85 : 1;
  const adjustedRunwayMonths = rawRunwayMonths * volatilityDiscount;

  return {
    totalMonthlyBurn: Math.round(totalMonthlyBurn),
    rawRunwayMonths: Math.round(rawRunwayMonths * 10) / 10,
    adjustedRunwayMonths: Math.round(adjustedRunwayMonths * 10) / 10,
    volatilityDiscountApplied: volatilityDiscount !== 1,
  };
}

// ---------------------------------------------------------------------------
// Tool 10: generate_health_report  (ties everything together)
// ---------------------------------------------------------------------------
function generateHealthReport() {
  const profile = getUserProfile();
  const transactions = getTransactions();
  const essentialMonthly = Object.values(
    profile.monthlyEssentialExpenses
  ).reduce((s, v) => s + v, 0);

  const recurring = detectRecurringCharges(transactions);
  const feeLeaks = detectFeeLeaks(transactions, getFeeRules());
  const subscriptionAssessments = assessSubscriptionValue(recurring, getUsageSignals());

  const subscriptionMonthlyTotal = subscriptionAssessments.reduce(
    (s, x) => s + x.monthlyAmount,
    0
  );
  const feeLeaksMonthlyTotal = feeLeaks.reduce((s, x) => s + x.monthlyAvg, 0);

  const incomePattern = analyzeIncomePattern(getIncomeHistory());
  const buffer = calculateRecommendedBuffer(incomePattern, essentialMonthly);

  const runway = calculateRunway({
    currentSavings: profile.currentSavings,
    essentialMonthly,
    feeLeaksMonthlyTotal,
    subscriptionMonthlyTotal,
    incomeStability: incomePattern.stability,
  });

  const flaggedSubs = subscriptionAssessments.filter((s) => s.status !== "keep");
  const potentialMonthlySavings =
    Math.round(
      (flaggedSubs.reduce((s, x) => s + x.monthlyAmount, 0) +
        feeLeaksMonthlyTotal) *
        100
    ) / 100;

  const narrative = `You have about ${runway.adjustedRunwayMonths} months of runway at your current burn rate of ₹${runway.totalMonthlyBurn.toLocaleString(
    "en-IN"
  )}/month. Your income is ${incomePattern.stability}${
    incomePattern.stability === "volatile"
      ? ", so I've applied a caution discount to the runway estimate"
      : ""
  }. I found ₹${potentialMonthlySavings.toLocaleString(
    "en-IN"
  )}/month in leaks worth a second look — mostly stale subscriptions and avoidable bank fees.`;

  return {
    generatedAt: TODAY.toISOString(),
    profile,
    essentialMonthly,
    recurringCharges: recurring,
    feeLeaks,
    subscriptionAssessments,
    incomePattern,
    buffer,
    runway,
    potentialMonthlySavings,
    narrative,
  };
}

// ---------------------------------------------------------------------------
// Tool 11: trigger_crisis_mode
// ---------------------------------------------------------------------------
function triggerCrisisMode(healthReport = generateHealthReport()) {
  return {
    mode: "crisis",
    triggeredAt: TODAY.toISOString(),
    baseReport: healthReport,
  };
}

// ---------------------------------------------------------------------------
// Tool 12: prioritize_expenses
// ---------------------------------------------------------------------------
function prioritizeExpenses(healthReport = generateHealthReport()) {
  const { profile, subscriptionAssessments, feeLeaks } = healthReport;

  const nonNegotiable = Object.entries(profile.monthlyEssentialExpenses).map(
    ([name, amount]) => ({
      name: name.replace(/_/g, " "),
      monthlyAmount: amount,
      type: "non_negotiable",
    })
  );

  const cuttable = [
    ...subscriptionAssessments.map((s) => ({
      id: `sub:${s.merchant}`,
      name: s.merchant,
      monthlyAmount: s.monthlyAmount,
      type: "cuttable",
      kind: "subscription",
      urgency: s.status === "cancel" ? "high" : s.status === "question" ? "medium" : "low",
      reason: s.reason,
    })),
    ...feeLeaks.map((f) => ({
      id: `fee:${f.merchant}`,
      name: f.merchant,
      monthlyAmount: f.monthlyAvg,
      type: "cuttable",
      kind: "fee",
      urgency: "medium",
      reason: f.rule ? f.rule.avoidanceTip : "Avoidable bank charge.",
    })),
  ].sort((a, b) => b.monthlyAmount - a.monthlyAmount);

  return { nonNegotiable, cuttable };
}

// ---------------------------------------------------------------------------
// Tool 13: generate_action_plan
// ---------------------------------------------------------------------------
function generateActionPlan(healthReport = generateHealthReport()) {
  const prioritized = prioritizeExpenses(healthReport);
  const recommendedCuts = prioritized.cuttable.filter(
    (c) => c.urgency === "high" || c.urgency === "medium"
  );

  const cuttableSavings = recommendedCuts.reduce(
    (s, c) => s + c.monthlyAmount,
    0
  );
  const newMonthlyBurn = Math.max(
    0,
    healthReport.runway.totalMonthlyBurn - cuttableSavings
  );
  const newRunwayMonths =
    Math.round((healthReport.profile.currentSavings / newMonthlyBurn) * 10) /
    10;

  const steps = [];
  let day = 1;
  const subCuts = recommendedCuts.filter((c) => c.kind === "subscription");
  const feeCuts = recommendedCuts.filter((c) => c.kind === "fee");

  if (subCuts.length) {
    steps.push({
      day,
      action: `Cancel or pause: ${subCuts.map((c) => c.name).join(", ")}`,
      monthlySavings: subCuts.reduce((s, c) => s + c.monthlyAmount, 0),
    });
  }
  day = 1;
  if (feeCuts.length) {
    steps.push({
      day,
      action: `Change behavior to stop: ${feeCuts.map((c) => c.name).join(", ")}`,
      monthlySavings: Math.round(feeCuts.reduce((s, c) => s + c.monthlyAmount, 0)),
    });
  }
  steps.push({
    day: 7,
    action:
      "Move non-essential discretionary spending (dining out, entertainment) to a strict weekly cap.",
    monthlySavings: 0,
  });
  steps.push({
    day: 14,
    action:
      "Reach out to existing clients/gig platforms to line up any available short-notice work.",
    monthlySavings: 0,
  });
  steps.push({
    day: 30,
    action:
      "Re-run this health check to confirm the new burn rate and adjust the plan.",
    monthlySavings: 0,
  });

  return {
    recommendedCuts,
    cuttableSavings: Math.round(cuttableSavings),
    newMonthlyBurn: Math.round(newMonthlyBurn),
    newRunwayMonths,
    extendedByMonths:
      Math.round((newRunwayMonths - healthReport.runway.adjustedRunwayMonths) * 10) /
      10,
    steps,
  };
}

// ---------------------------------------------------------------------------
// Tool 14: apply_recommended_cuts  (requires human approval — enforced by caller)
// ---------------------------------------------------------------------------
function applyRecommendedCuts(itemIds, approved) {
  if (!approved) {
    return {
      applied: false,
      message: "No changes made — approval was not granted.",
      itemIds,
    };
  }
  return {
    applied: true,
    message: `Applied cuts to ${itemIds.length} item(s). Nothing was executed automatically — this reflects your explicit approval.`,
    itemIds,
    appliedAt: TODAY.toISOString(),
  };
}

module.exports = {
  TODAY,
  getTransactions,
  getIncomeHistory,
  getFeeRules,
  getUsageSignals,
  getUserProfile,
  detectRecurringCharges,
  classifyCharge,
  detectFeeLeaks,
  assessSubscriptionValue,
  analyzeIncomePattern,
  calculateRecommendedBuffer,
  calculateRunway,
  generateHealthReport,
  triggerCrisisMode,
  prioritizeExpenses,
  generateActionPlan,
  applyRecommendedCuts,
};
