# FinShield — AI Financial Resilience Copilot

FinShield watches your money for silent leaks (stale subscriptions, hidden
bank fees), understands whether your income is stable or fragile, and — the
moment you simulate a crisis — hands you a concrete, numbered survival plan.
It never cancels or flags anything without your explicit approval.

This repo contains **two independent, fully-working ways to run FinShield**,
both built on the same core logic:

| Folder | What it is |
|---|---|
| `shared/` | The core engine (14-tool pipeline) + all mock data. Both surfaces below import this. |
| `mcp-server/` | A real **MCP server** (stdio) exposing FinShield as 14 tools, 4 resources, and 1 prompt — plug it into Claude Desktop, Claude Code, or any MCP client. |
| `web-app/` | A full **website** (Express backend + React frontend) with a chat panel, a live dashboard, and a Tool-Approval modal — this is the polished, demoable product. |

You can run either one on its own, or both.

---

## 1. Requirements

- **Node.js 18 or newer** ([download](https://nodejs.org)) — check with `node -v`
- npm (comes with Node)

No API keys, no database, no external services required. Everything runs
locally against mock data in `shared/data/`.

---

## 2. Running the website (recommended — the full demo)

The website is two processes: a backend API (port 4000) and a frontend dev
server (port 5173). Open **two terminals**.

**Terminal 1 — backend:**
```bash
cd web-app/server
npm install
npm start
```
You should see: `FinShield web server listening on http://localhost:4000`

**Terminal 2 — frontend:**
```bash
cd web-app/client
npm install
npm run dev
```
Vite will print a local URL, typically `http://localhost:5173`. Open it in
your browser.

### Using it
- The dashboard loads with your **Health View**: a runway dial, income
  stability, and a leak ledger (green = keep, amber = question, red = cancel).
- Type or click **"What if I lost my income today?"** in the chat panel to
  trigger **Crisis Mode** — the dashboard flips to a recalculated runway, a
  30-day action plan, and a **Tool Approval** modal asking permission to flag
  subscriptions for cancellation.
- Click **Allow** or **Deny** (or just type "yes"/"no" in chat) — nothing is
  ever cancelled automatically.
- The circular reset icon (top right) clears the session and restarts the
  demo from scratch.

If you want to build a static production bundle instead of the dev server:
```bash
cd web-app/client
npm run build
npm run preview   # serves the built dist/ folder
```

---

## 3. Running the MCP server

This exposes the exact same 14-tool pipeline as a standalone MCP server over
stdio, so any MCP-compatible client (Claude Desktop, Claude Code, etc.) can
call it directly.

```bash
cd mcp-server
npm install
```

Then point your MCP client at it. For **Claude Desktop**, add this to your
`claude_desktop_config.json` (Settings → Developer → Edit Config):

```json
{
  "mcpServers": {
    "finshield": {
      "command": "node",
      "args": ["/absolute/path/to/finshield/mcp-server/src/index.js"]
    }
  }
}
```

Replace the path with the real absolute path to this folder on your machine,
then restart Claude Desktop. You should see a "finshield" server with 14
tools, 4 resources, and 1 prompt available.

### Try asking Claude (once connected)
> "Use FinShield to check my financial health."
> "I just lost my job — what should I do?"

Claude will chain the tools itself (`get_transactions` →
`detect_recurring_charges` → … → `generate_health_report`, etc.), and will
show its own native tool-approval UI before calling `apply_recommended_cuts`
with `approved: true`.

### Run it standalone (no client) to sanity-check it starts
```bash
cd mcp-server
node src/index.js
```
You should see `FinShield MCP server running on stdio` on stderr. Press
`Ctrl+C` to stop — it's waiting for an MCP client to talk to it over stdin.

---

## 4. Project structure

```
finshield/
├── shared/
│   ├── engine.js              # the 14-tool financial reasoning pipeline
│   └── data/
│       ├── transactions.json      # ~90 days of mock bank transactions
│       ├── income_history.json    # 6 months of mock gig-worker income
│       ├── fee_rules.json         # reference table of bank fee types
│       ├── usage_signals.json     # mock subscription engagement data
│       └── user_profile.json      # savings + essential monthly expenses
│
├── mcp-server/
│   ├── package.json
│   └── src/index.js           # MCP server: 14 tools, 4 resources, 1 prompt
│
└── web-app/
    ├── server/                # Express API (reuses shared/engine.js)
    │   ├── index.js
    │   └── chatOrchestrator.js
    └── client/                # React + Vite + Tailwind frontend
        └── src/
            ├── App.jsx
            ├── api.js
            └── components/
                ├── ChatPanel.jsx
                ├── Dashboard.jsx
                ├── HealthView.jsx
                ├── CrisisView.jsx
                ├── RunwayDial.jsx      # the vault-dial runway gauge
                ├── LeakCard.jsx
                ├── ApprovalModal.jsx
                └── Counter.jsx
```

## 5. How the 14 tools map to the pipeline

`get_transactions` and `get_income_history` are the raw feeds.
`detect_recurring_charges` + `classify_charge` + `detect_fee_leaks` +
`assess_subscription_value` find and judge every leak. `analyze_income_pattern`
+ `calculate_recommended_buffer` handle income fragility. `calculate_runway`
and `generate_health_report` tie it all into the headline "months of runway"
number. `trigger_crisis_mode` → `prioritize_expenses` →
`generate_action_plan` produce the 30-day survival plan, and
`apply_recommended_cuts` is the human-in-the-loop gate — it only executes
when explicitly approved.

The exact same functions in `shared/engine.js` back both the MCP tools and
the web app's REST endpoints, so the two surfaces can never drift apart.

## 6. Notes on the mock data

The "as of" date used throughout the demo is fixed to **26 July 2026** (see
`TODAY` in `shared/engine.js`) so the mock data always reads as fresh,
regardless of what day you actually run it. Feel free to edit the JSON files
in `shared/data/` — every tool reads from disk, so changes take effect on the
next request/tool call without any code changes.
