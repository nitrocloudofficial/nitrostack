const express = require("express");
const cors = require("cors");
const path = require("path");
const engine = require(path.join(__dirname, "..", "..", "shared", "engine.js"));
const orchestrator = require("./chatOrchestrator");

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 4000;

// In-memory sessions — fine for a local demo, resets on server restart.
const sessions = new Map();
function getSession(id) {
  const key = id || "default";
  if (!sessions.has(key)) {
    sessions.set(key, { mode: "health" });
  }
  return sessions.get(key);
}

app.get("/api/ping", (_req, res) => res.json({ ok: true, name: "finshield-web-server" }));

// Full state for a session (used on initial page load)
app.get("/api/state", (req, res) => {
  const session = getSession(req.query.sessionId);
  orchestrator.ensureHealthReport(session);
  res.json(orchestrator.widgetState(session));
});

// Main chat endpoint — the "AI Chat" surface
app.post("/api/chat", (req, res) => {
  const { sessionId, message } = req.body || {};
  const session = getSession(sessionId);
  const result = orchestrator.handleMessage(session, message || "");
  res.json(result);
});

// Explicit approve/deny action for the Tool Approval modal
app.post("/api/approve", (req, res) => {
  const { sessionId, approved } = req.body || {};
  const session = getSession(sessionId);
  if (!session.pendingApproval) {
    return res.status(400).json({ error: "No pending approval for this session." });
  }
  const result = orchestrator.resolveApproval(session, !!approved);
  res.json(result);
});

// Reset a session back to a clean slate (handy for re-running the demo)
app.post("/api/reset", (req, res) => {
  const { sessionId } = req.body || {};
  sessions.delete(sessionId || "default");
  const session = getSession(sessionId);
  orchestrator.ensureHealthReport(session);
  res.json(orchestrator.widgetState(session));
});

// Raw tool endpoints — lets you inspect each step of the pipeline directly,
// mirroring the 14 MCP tools 1:1 (handy for debugging / grading the pipeline).
app.get("/api/tools/transactions", (_req, res) => res.json(engine.getTransactions()));
app.get("/api/tools/income-history", (_req, res) => res.json(engine.getIncomeHistory()));
app.get("/api/tools/recurring-charges", (_req, res) => res.json(engine.detectRecurringCharges()));
app.get("/api/tools/fee-leaks", (_req, res) => res.json(engine.detectFeeLeaks()));
app.get("/api/tools/subscription-assessment", (_req, res) => res.json(engine.assessSubscriptionValue()));
app.get("/api/tools/income-pattern", (_req, res) => res.json(engine.analyzeIncomePattern()));
app.get("/api/tools/health-report", (_req, res) => res.json(engine.generateHealthReport()));
app.get("/api/tools/action-plan", (_req, res) => res.json(engine.generateActionPlan()));

app.listen(PORT, () => {
  console.log(`FinShield web server listening on http://localhost:${PORT}`);
});
