const path = require("path");
const engine = require(path.join(__dirname, "..", "..", "shared", "engine.js"));

function inr(n) {
  return `₹${Math.round(n).toLocaleString("en-IN")}`;
}

/**
 * Builds (or reuses) the cached health report for a session.
 */
function ensureHealthReport(session) {
  if (!session.healthReport) {
    session.healthReport = engine.generateHealthReport();
  }
  return session.healthReport;
}

function healthSummaryReply(report) {
  const flagged = report.subscriptionAssessments.filter((s) => s.status !== "keep");
  const lines = [];
  lines.push(
    `You have **${report.runway.adjustedRunwayMonths} months of runway** at your current burn rate of ${inr(
      report.runway.totalMonthlyBurn
    )}/month.`
  );
  lines.push(
    `Your income is **${report.incomePattern.stability}** — ${
      report.incomePattern.stability === "volatile"
        ? `it swung between ${inr(Math.min(...report.incomePattern.history.map((h) => h.amount)))} and ${inr(
            Math.max(...report.incomePattern.history.map((h) => h.amount))
          )} over the last ${report.incomePattern.history.length} months, so I've applied a caution discount to the runway above.`
        : "it's been consistent month to month."
    }`
  );
  if (flagged.length) {
    lines.push(
      `I found ${inr(report.potentialMonthlySavings)}/month in leaks worth a look:`
    );
    for (const f of flagged) {
      lines.push(`• **${f.merchant}** (${inr(f.monthlyAmount)}/mo) — ${f.reason}`);
    }
    for (const fee of report.feeLeaks) {
      lines.push(`• **${fee.merchant}** (~${inr(fee.monthlyAvg)}/mo) — ${fee.rule ? fee.rule.avoidanceTip : "avoidable bank charge."}`);
    }
  } else {
    lines.push("No major leaks found right now — your recurring spending looks clean.");
  }
  lines.push(
    `I'd also recommend building a ${inr(report.buffer.recommendedBufferAmount)} buffer (about ${report.buffer.recommendedBufferMonths} months of essentials) to smooth over your leaner months.`
  );
  return lines.join("\n\n");
}

function crisisSummaryReply(report, actionPlan) {
  const lines = [];
  lines.push(
    `Understood — switching to crisis mode. If your income stopped today, cutting the flagged expenses now extends your runway from **${report.runway.adjustedRunwayMonths} months to ${actionPlan.newRunwayMonths} months** (+${actionPlan.extendedByMonths} months).`
  );
  lines.push(`Here's the plan:`);
  for (const step of actionPlan.steps) {
    lines.push(
      `**Day ${step.day}** — ${step.action}${
        step.monthlySavings ? ` (saves ~${inr(step.monthlySavings)}/mo)` : ""
      }`
    );
  }
  return lines.join("\n\n");
}

function buildApprovalRequest(actionPlan) {
  const subCuts = actionPlan.recommendedCuts.filter((c) => c.kind === "subscription");
  if (subCuts.length === 0) return null;
  return {
    itemIds: subCuts.map((c) => c.id),
    items: subCuts,
    summary: `Should I flag these ${subCuts.length} subscription${
      subCuts.length > 1 ? "s" : ""
    } for cancellation — ${subCuts.map((c) => c.name).join(", ")}? This saves ${inr(
      subCuts.reduce((s, c) => s + c.monthlyAmount, 0)
    )}/month. I won't cancel anything until you approve.`,
  };
}

function widgetState(session) {
  return {
    view: session.mode,
    healthReport: session.healthReport || null,
    actionPlan: session.actionPlan || null,
    appliedCuts: session.appliedCuts || [],
    pendingApproval: session.pendingApproval || null,
  };
}

const CRISIS_RE = /\b(lost my (job|income)|lost income|got fired|laid off|no more income|no income|financial crisis|emergency|what if i lose)\b/i;
const APPROVE_RE = /\b(yes|approve|allow|go ahead|confirm|do it|sounds good)\b/i;
const DENY_RE = /\b(no|deny|don'?t|stop|not now|cancel that|hold off)\b/i;
const HEALTH_RE = /\b(health|how am i doing|financial health|runway|leak|overview|summary)\b/i;

function handleMessage(session, rawMessage) {
  const message = (rawMessage || "").trim();
  const lower = message.toLowerCase();

  // 1. If there's a pending approval, check if the reply resolves it.
  if (session.pendingApproval) {
    if (APPROVE_RE.test(lower)) {
      return resolveApproval(session, true);
    }
    if (DENY_RE.test(lower)) {
      return resolveApproval(session, false);
    }
    // otherwise fall through — user asked something else while a prompt is open
  }

  // 2. Crisis trigger
  if (CRISIS_RE.test(lower)) {
    return triggerCrisis(session);
  }

  // 3. Explicit health check, or default first message
  if (HEALTH_RE.test(lower) || !session.healthReport) {
    return healthCheck(session);
  }

  // 4. Fallback — re-show whatever we have
  const report = ensureHealthReport(session);
  return {
    reply:
      "I can tell you about your financial health, or you can simulate a shock — try asking \"what if I lost my job?\".",
    widgetState: widgetState(session),
  };
}

function healthCheck(session) {
  session.mode = "health";
  const report = ensureHealthReport(session);
  return { reply: healthSummaryReply(report), widgetState: widgetState(session) };
}

function triggerCrisis(session) {
  const report = ensureHealthReport(session);
  session.mode = "crisis";
  session.crisis = engine.triggerCrisisMode(report);
  session.actionPlan = engine.generateActionPlan(report);
  session.pendingApproval = buildApprovalRequest(session.actionPlan);

  let reply = crisisSummaryReply(report, session.actionPlan);
  if (session.pendingApproval) {
    reply += `\n\n**Tool Approval requested:** ${session.pendingApproval.summary}`;
  }
  return { reply, widgetState: widgetState(session) };
}

function resolveApproval(session, approved) {
  const pending = session.pendingApproval;
  session.pendingApproval = null;
  const result = engine.applyRecommendedCuts(pending.itemIds, approved);

  if (approved) {
    session.appliedCuts = [...(session.appliedCuts || []), ...pending.items];
  }

  const reply = approved
    ? `Done — I've flagged ${pending.items.map((i) => i.name).join(", ")} for cancellation. ${result.message}`
    : `No problem, I've left everything as-is. ${result.message}`;

  return { reply, widgetState: widgetState(session) };
}

module.exports = {
  handleMessage,
  healthCheck,
  triggerCrisis,
  resolveApproval,
  widgetState,
  ensureHealthReport,
};
