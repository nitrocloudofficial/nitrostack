const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";

function getSessionId() {
  let id = sessionStorage.getItem("finshield_session_id");
  if (!id) {
    id = `session_${Math.random().toString(36).slice(2)}_${Date.now()}`;
    sessionStorage.setItem("finshield_session_id", id);
  }
  return id;
}

async function post(pathName, body) {
  const res = await fetch(`${BASE_URL}${pathName}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ sessionId: getSessionId(), ...body }),
  });
  if (!res.ok) throw new Error(`Request to ${pathName} failed: ${res.status}`);
  return res.json();
}

async function get(pathName) {
  const res = await fetch(`${BASE_URL}${pathName}?sessionId=${getSessionId()}`);
  if (!res.ok) throw new Error(`Request to ${pathName} failed: ${res.status}`);
  return res.json();
}

export const api = {
  getState: () => get("/api/state"),
  sendMessage: (message) => post("/api/chat", { message }),
  approve: (approved) => post("/api/approve", { approved }),
  reset: () => post("/api/reset", {}),
};
