const STATUS_STYLES = {
  keep: { dot: "bg-keep", text: "text-keep", label: "Keep", ring: "border-keep/25" },
  question: { dot: "bg-question", text: "text-question", label: "Question", ring: "border-question/25" },
  cancel: { dot: "bg-cancel", text: "text-cancel", label: "Cancel", ring: "border-cancel/25" },
  fee: { dot: "bg-question", text: "text-question", label: "Fee Leak", ring: "border-question/25" },
};

function inr(n) {
  return `₹${Math.round(n).toLocaleString("en-IN")}`;
}

export default function LeakCard({ name, monthlyAmount, status, reason, checked, onToggle, selectable }) {
  const style = STATUS_STYLES[status] || STATUS_STYLES.question;
  return (
    <div
      className={`group relative rounded-lg border ${style.ring} bg-raised/60 px-4 py-3 transition hover:bg-raised animate-risein`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-2.5 min-w-0">
          {selectable && (
            <input
              type="checkbox"
              checked={checked}
              onChange={onToggle}
              className="mt-1 h-3.5 w-3.5 accent-brass shrink-0"
            />
          )}
          <span className={`mt-1.5 h-1.5 w-1.5 rounded-full shrink-0 ${style.dot}`} />
          <div className="min-w-0">
            <p className="font-medium text-paper text-sm truncate">{name}</p>
            <p className="text-xs text-mist mt-0.5 leading-snug">{reason}</p>
          </div>
        </div>
        <div className="text-right shrink-0">
          <p className="font-mono text-sm text-paper tabular-nums">{inr(monthlyAmount)}</p>
          <p className={`text-[10px] uppercase tracking-wide mt-1 font-medium ${style.text}`}>
            {style.label}
          </p>
        </div>
      </div>
    </div>
  );
}
