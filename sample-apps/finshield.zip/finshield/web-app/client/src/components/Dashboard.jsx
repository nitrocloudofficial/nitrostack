import HealthView from "./HealthView";
import CrisisView from "./CrisisView";

export default function Dashboard({ widgetState }) {
  const { view, healthReport, actionPlan, appliedCuts } = widgetState || {};

  if (!healthReport) {
    return (
      <div className="h-full flex items-center justify-center text-mist text-sm">
        Loading your financial picture…
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto">
      {view === "crisis" ? (
        <CrisisView report={healthReport} actionPlan={actionPlan} appliedCuts={appliedCuts || []} />
      ) : (
        <HealthView report={healthReport} />
      )}
    </div>
  );
}
