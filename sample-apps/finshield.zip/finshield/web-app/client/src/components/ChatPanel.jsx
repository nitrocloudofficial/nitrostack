import { useEffect, useRef, useState } from "react";
import MiniMarkdown from "../lib/miniMarkdown.jsx";

const QUICK_ACTIONS = ["How's my financial health?", "What if I lost my income today?"];

export default function ChatPanel({ messages, onSend, loading }) {
  const [draft, setDraft] = useState("");
  const scrollRef = useRef(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  function submit(text) {
    const value = (text ?? draft).trim();
    if (!value || loading) return;
    onSend(value);
    setDraft("");
  }

  return (
    <div className="flex flex-col h-full bg-surface border-r border-line">
      <div className="px-5 py-4 border-b border-line">
        <p className="text-[10px] uppercase tracking-[0.2em] text-brass">FinShield Advisor</p>
        <p className="text-xs text-mist mt-1">Ask about your finances, or simulate a shock.</p>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[90%] rounded-xl px-3.5 py-2.5 ${
                m.role === "user"
                  ? "bg-brass text-ink text-sm font-medium"
                  : "bg-raised/60 border border-line text-paper"
              }`}
            >
              {m.role === "user" ? m.text : <MiniMarkdown text={m.text} />}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="rounded-xl px-3.5 py-2.5 bg-raised/60 border border-line">
              <span className="flex gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-brass animate-pulse" />
                <span className="h-1.5 w-1.5 rounded-full bg-brass animate-pulse [animation-delay:150ms]" />
                <span className="h-1.5 w-1.5 rounded-full bg-brass animate-pulse [animation-delay:300ms]" />
              </span>
            </div>
          </div>
        )}
      </div>

      <div className="px-5 py-3 border-t border-line space-y-2">
        <div className="flex flex-wrap gap-2">
          {QUICK_ACTIONS.map((q) => (
            <button
              key={q}
              onClick={() => submit(q)}
              disabled={loading}
              className="text-xs rounded-full border border-line px-3 py-1.5 text-mist hover:text-paper hover:border-brass/40 transition disabled:opacity-50"
            >
              {q}
            </button>
          ))}
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
          className="flex gap-2"
        >
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="Message FinShield…"
            disabled={loading}
            className="flex-1 rounded-lg bg-raised border border-line px-3.5 py-2.5 text-sm text-paper placeholder:text-mist/60 focus:outline-none focus:border-brass/50 focus:ring-1 focus:ring-brass/30"
          />
          <button
            type="submit"
            disabled={loading || !draft.trim()}
            className="rounded-lg bg-brass px-4 py-2.5 text-sm font-semibold text-ink hover:bg-brass/90 transition disabled:opacity-40"
          >
            Send
          </button>
        </form>
      </div>
    </div>
  );
}
