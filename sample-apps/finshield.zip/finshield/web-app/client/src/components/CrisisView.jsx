import RunwayDial from "./RunwayDial";
import Counter from "./Counter";

function inr(n) {
  return `₹${Math.round(n).toLocaleString("en-IN")}`;
}

export default function CrisisView({ report, actionPlan, appliedCuts }) {
  if (!report || !actionPlan) return null;
  const appliedIds = new Set(appliedCuts.map((c) => c.id));

  return (
    <div className="space-y-6">
      {/* Stamp banner */}
      <div className="flex items-center gap-3">
        <span className="animate-stampin inline-flex items-center gap-2 rounded-md border-2 border-crisis text-crisis px-3 py-1 font-display font-semibold tracking-wide -rotate-3 text-sm">
          CRISIS MODE
        </span>
        <p className="text-xs text-mist">Triage triggered — re-prioritizing from existing leak data, nothing recomputed from scratch.</p>
      </div>

      {/* Hero: before/after runway */}
      <div className="rounded-2xl border border-crisis/30 bg-surface p-6 shadow-vault">
        <div className="flex flex-col lg:flex-row items-center lg:items-start gap-8">
          <div className="flex items-center gap-6">
            <div className="opacity-50 scale-90 origin-right">
              <RunwayDial months={report.runway.adjustedRunwayMonths} max={6} label="runway before cuts" />
            </div>
            <RunwayDial months={actionPlan.newRunwayMonths} max={6} label="runway after recommended cuts" />
          </div>

          <div className="flex-1 w-full grid grid-cols-2 gap-4">
            <div className="rounded-lg bg-raised/50 border border-line px-4 py-3">
              <p className="text-[10px] uppercase tracking-wider text-mist mb-1">Runway extended by</p>
              <p className="font-mono text-lg text-keep">+{actionPlan.extendedByMonths} months</p>
            </div>
            <div className="rounded-lg bg-raised/50 border border-line px-4 py-3">
              <p className="text-[10px] uppercase tracking-wider text-mist mb-1">New monthly burn</p>
              <p className="font-mono text-lg text-paper">
                <Counter value={actionPlan.newMonthlyBurn} prefix="₹" />
              </p>
            </div>
            <div className="rounded-lg bg-raised/50 border border-line px-4 py-3 col-span-2">
              <p className="text-[10px] uppercase tracking-wider text-mist mb-1">Recommended monthly savings</p>
              <p className="font-mono text-lg text-brass">
                <Counter value={actionPlan.cuttableSavings} prefix="₹" />
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 30-day plan */}
      <div>
        <h3 className="font-display text-lg text-paper mb-3">30-Day Action Plan</h3>
        <ol className="space-y-2.5">
          {actionPlan.steps.map((step, i) => (
            <li
              key={i}
              className="flex gap-4 rounded-lg border border-line bg-raised/40 px-4 py-3 animate-risein"
              style={{ animationDelay: `${i * 60}ms` }}
            >
              <span className="font-mono text-brass text-xs shrink-0 pt-0.5 w-14">DAY {step.day}</span>
              <div className="flex-1">
                <p className="text-sm text-paper">{step.action}</p>
              </div>
              {step.monthlySavings > 0 && (
                <span className="font-mono text-xs text-keep shrink-0">
                  save {inr(step.monthlySavings)}/mo
                </span>
              )}
            </li>
          ))}
        </ol>
      </div>

      {/* Cuttable vs non-negotiable */}
      <div className="grid md:grid-cols-2 gap-4">
        <div className="rounded-lg border border-line bg-raised/30 p-4">
          <h4 className="text-xs uppercase tracking-wider text-mist mb-3">Non-negotiable</h4>
          <ul className="space-y-2 text-sm">
            {Object.entries(report.profile.monthlyEssentialExpenses).map(([name, amt]) => (
              <li key={name} className="flex justify-between text-paper/90">
                <span className="capitalize">{name.replace(/_/g, " ")}</span>
                <span className="font-mono text-mist">{inr(amt)}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="rounded-lg border border-line bg-raised/30 p-4">
          <h4 className="text-xs uppercase tracking-wider text-mist mb-3">Recommended cuts</h4>
          <ul className="space-y-2 text-sm">
            {actionPlan.recommendedCuts.map((c) => (
              <li key={c.id} className="flex justify-between items-center text-paper/90">
                <span className="flex items-center gap-2">
                  {appliedIds.has(c.id) && (
                    <span className="text-[9px] uppercase tracking-wide bg-keep/15 text-keep border border-keep/30 rounded px-1.5 py-0.5">
                      applied
                    </span>
                  )}
                  {c.name}
                </span>
                <span className="font-mono text-mist">{inr(c.monthlyAmount)}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
