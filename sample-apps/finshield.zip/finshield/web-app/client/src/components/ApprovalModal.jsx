function inr(n) {
  return `₹${Math.round(n).toLocaleString("en-IN")}`;
}

export default function ApprovalModal({ pendingApproval, onApprove, onDeny, busy }) {
  if (!pendingApproval) return null;

  const total = pendingApproval.items.reduce((s, i) => s + i.monthlyAmount, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/70 backdrop-blur-sm px-4">
      <div className="w-full max-w-md rounded-2xl border border-brass/30 bg-surface shadow-vault overflow-hidden animate-risein">
        <div className="border-b border-line px-5 py-4 flex items-center justify-between">
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-brass">Tool Approval Required</p>
            <h3 className="font-display text-lg text-paper mt-0.5">apply_recommended_cuts</h3>
          </div>
          <div className="h-8 w-8 rounded-full border border-brass/40 flex items-center justify-center text-brass font-display">
            !
          </div>
        </div>

        <div className="px-5 py-4">
          <p className="text-sm text-paper/90 leading-relaxed mb-4">
            FinShield wants to flag the following for cancellation. Nothing executes until you approve.
          </p>

          <ul className="space-y-2 mb-4">
            {pendingApproval.items.map((item) => (
              <li
                key={item.id}
                className="flex justify-between items-center rounded-lg border border-line bg-raised/50 px-3 py-2 text-sm"
              >
                <span className="text-paper">{item.name}</span>
                <span className="font-mono text-mist">{inr(item.monthlyAmount)}/mo</span>
              </li>
            ))}
          </ul>

          <div className="flex justify-between items-center text-sm font-mono border-t border-line pt-3">
            <span className="text-mist uppercase text-xs tracking-wide">Total monthly savings</span>
            <span className="text-brass">{inr(total)}</span>
          </div>
        </div>

        <div className="px-5 py-4 bg-raised/40 border-t border-line flex gap-3">
          <button
            onClick={onDeny}
            disabled={busy}
            className="flex-1 rounded-lg border border-line px-4 py-2.5 text-sm font-medium text-mist hover:text-paper hover:border-mist transition disabled:opacity-50"
          >
            Deny
          </button>
          <button
            onClick={onApprove}
            disabled={busy}
            className="flex-1 rounded-lg bg-brass px-4 py-2.5 text-sm font-semibold text-ink hover:bg-brass/90 transition disabled:opacity-50"
          >
            Allow
          </button>
        </div>
      </div>
    </div>
  );
}
