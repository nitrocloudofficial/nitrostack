const START_ANGLE = -130;
const END_ANGLE = 130;
const ARC = END_ANGLE - START_ANGLE;

function angleFor(value, max) {
  const clamped = Math.max(0, Math.min(value, max));
  return START_ANGLE + (clamped / max) * ARC;
}

function polar(cx, cy, r, angleDeg) {
  const a = ((angleDeg - 90) * Math.PI) / 180;
  return { x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) };
}

function zoneColor(months) {
  if (months < 1.5) return "#D9614F"; // cancel
  if (months < 3) return "#E0A93A"; // question
  return "#4FAE7C"; // keep
}

export default function RunwayDial({ months, max = 6, label = "months of runway" }) {
  const cx = 140;
  const cy = 140;
  const r = 108;

  const ticks = [];
  const step = 0.5;
  for (let v = 0; v <= max + 0.001; v += step) {
    const isMajor = Number.isInteger(v);
    const angle = angleFor(v, max);
    const outer = polar(cx, cy, r, angle);
    const inner = polar(cx, cy, r - (isMajor ? 14 : 8), angle);
    ticks.push(
      <line
        key={v}
        x1={inner.x}
        y1={inner.y}
        x2={outer.x}
        y2={outer.y}
        stroke={isMajor ? "#C9A227" : "#5B6786"}
        strokeWidth={isMajor ? 2 : 1}
        strokeLinecap="round"
      />
    );
  }

  const needleAngle = angleFor(months, max);
  const needleTip = polar(cx, cy, r - 22, needleAngle);
  const needleTail = polar(cx, cy, 18, needleAngle + 180);
  const color = zoneColor(months);

  const arcStart = polar(cx, cy, r + 10, START_ANGLE);
  const arcEnd = polar(cx, cy, r + 10, angleFor(months, max));
  const largeArc = angleFor(months, max) - START_ANGLE > 180 ? 1 : 0;

  return (
    <div className="relative flex flex-col items-center select-none">
      <svg viewBox="0 0 280 280" className="w-64 h-64">
        <circle cx={cx} cy={cy} r={r + 24} fill="#161D2E" stroke="#2A3348" strokeWidth="1" />
        <circle cx={cx} cy={cy} r={r + 10} fill="none" stroke="#2A3348" strokeWidth="1" />

        {/* progress arc reflecting current zone */}
        <path
          d={`M ${arcStart.x} ${arcStart.y} A ${r + 10} ${r + 10} 0 ${largeArc} 1 ${arcEnd.x} ${arcEnd.y}`}
          fill="none"
          stroke={color}
          strokeWidth="3"
          strokeLinecap="round"
          opacity="0.85"
        />

        {ticks}

        {/* needle */}
        <g style={{ transition: "transform 0.6s cubic-bezier(.2,.8,.2,1)" }}>
          <line
            x1={needleTail.x}
            y1={needleTail.y}
            x2={needleTip.x}
            y2={needleTip.y}
            stroke={color}
            strokeWidth="3"
            strokeLinecap="round"
          />
          <circle cx={cx} cy={cy} r="7" fill="#0E1420" stroke={color} strokeWidth="2" />
        </g>
      </svg>

      <div className="absolute top-[92px] flex flex-col items-center">
        <span className="font-mono text-5xl font-semibold tabular-nums" style={{ color }}>
          {months}
        </span>
        <span className="mt-1 text-[11px] uppercase tracking-[0.18em] text-mist text-center max-w-[10rem]">
          {label}
        </span>
      </div>
    </div>
  );
}
