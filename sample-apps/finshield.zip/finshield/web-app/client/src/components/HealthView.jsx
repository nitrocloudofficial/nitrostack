import RunwayDial from "./RunwayDial";
import LeakCard from "./LeakCard";
import Counter from "./Counter";

const STABILITY_STYLES = {
  stable: "text-keep border-keep/30 bg-keep/10",
  volatile: "text-question border-question/30 bg-question/10",
};

export default function HealthView({ report }) {
  if (!report) return null;
  const { runway, incomePattern, subscriptionAssessments, feeLeaks, potentialMonthlySavings, buffer, essentialMonthly } = report;

  return (
    <div className="space-y-6">
      {/* Hero: dial + key stats */}
      <div className="rounded-2xl border border-line bg-surface p-6 shadow-vault">
        <div className="flex flex-col lg:flex-row items-center lg:items-start gap-8">
          <RunwayDial months={runway.adjustedRunwayMonths} max={6} label="months you could survive with zero income" />

          <div className="flex-1 w-full grid grid-cols-2 gap-4">
            <div className="rounded-lg bg-raised/50 border border-line px-4 py-3">
              <p className="text-[10px] uppercase tracking-wider text-mist mb-1">Income stability</p>
              <span
                className={`inline-block rounded-full px-2.5 py-1 text-xs font-medium border ${
                  STABILITY_STYLES[incomePattern.stability]
                }`}
              >
                {incomePattern.stability === "stable" ? "Stable" : "Volatile"}
              </span>
              <p className="text-[11px] text-mist mt-2 leading-snug">
                {incomePattern.leanMonths.length} lean month{incomePattern.leanMonths.length === 1 ? "" : "s"} out of{" "}
                {incomePattern.history.length} tracked
              </p>
            </div>

            <div className="rounded-lg bg-raised/50 border border-line px-4 py-3">
              <p className="text-[10px] uppercase tracking-wider text-mist mb-1">Monthly burn</p>
              <p className="font-mono text-lg text-paper">
                <Counter value={runway.totalMonthlyBurn} prefix="₹" />
              </p>
              <p className="text-[11px] text-mist mt-1">essentials + subscriptions + fees</p>
            </div>

            <div className="rounded-lg bg-raised/50 border border-line px-4 py-3">
              <p className="text-[10px] uppercase tracking-wider text-mist mb-1">Potential monthly savings</p>
              <p className="font-mono text-lg text-brass">
                <Counter value={potentialMonthlySavings} prefix="₹" />
              </p>
              <p className="text-[11px] text-mist mt-1">if all flagged leaks are addressed</p>
            </div>

            <div className="rounded-lg bg-raised/50 border border-line px-4 py-3">
              <p className="text-[10px] uppercase tracking-wider text-mist mb-1">Recommended buffer</p>
              <p className="font-mono text-lg text-paper">
                <Counter value={buffer.recommendedBufferAmount} prefix="₹" />
              </p>
              <p className="text-[11px] text-mist mt-1">{buffer.recommendedBufferMonths} months of essentials</p>
            </div>
          </div>
        </div>
      </div>

      {/* Leak ledger */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-display text-lg text-paper">Leak Ledger</h3>
          <span className="text-xs text-mist font-mono">
            {subscriptionAssessments.length + feeLeaks.length} items reviewed
          </span>
        </div>
        <div className="space-y-2.5">
          {subscriptionAssessments.map((s) => (
            <LeakCard
              key={s.merchant}
              name={s.merchant}
              monthlyAmount={s.monthlyAmount}
              status={s.status}
              reason={s.reason}
            />
          ))}
          {feeLeaks.map((f) => (
            <LeakCard
              key={f.merchant}
              name={f.merchant}
              monthlyAmount={f.monthlyAvg}
              status="fee"
              reason={f.rule ? f.rule.avoidanceTip : "Avoidable bank charge."}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
