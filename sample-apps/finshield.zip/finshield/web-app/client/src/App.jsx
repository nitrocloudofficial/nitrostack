import { useEffect, useState, useCallback } from "react";
import { ShieldCheck, RotateCcw } from "lucide-react";
import ChatPanel from "./components/ChatPanel";
import Dashboard from "./components/Dashboard";
import ApprovalModal from "./components/ApprovalModal";
import { api } from "./api";

export default function App() {
  const [messages, setMessages] = useState([]);
  const [widgetState, setWidgetState] = useState(null);
  const [loading, setLoading] = useState(true);
  const [approvalBusy, setApprovalBusy] = useState(false);

  const bootstrap = useCallback(async () => {
    setLoading(true);
    try {
      const result = await api.sendMessage("How's my financial health?");
      setMessages([
        {
          role: "assistant",
          text: `Welcome — I'm FinShield, your financial resilience copilot. I've pulled your transactions, income history, and bank fee activity.\n\n${result.reply}`,
        },
      ]);
      setWidgetState(result.widgetState);
    } catch (err) {
      setMessages([
        {
          role: "assistant",
          text: `I couldn't reach the FinShield server. Make sure the backend is running (see README), then refresh this page.`,
        },
      ]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    bootstrap();
  }, [bootstrap]);

  async function handleSend(text) {
    setMessages((m) => [...m, { role: "user", text }]);
    setLoading(true);
    try {
      const result = await api.sendMessage(text);
      setMessages((m) => [...m, { role: "assistant", text: result.reply }]);
      setWidgetState(result.widgetState);
    } catch (err) {
      setMessages((m) => [...m, { role: "assistant", text: "Something went wrong reaching the server — please try again." }]);
    } finally {
      setLoading(false);
    }
  }

  async function handleApproval(approved) {
    setApprovalBusy(true);
    try {
      const result = await api.approve(approved);
      setMessages((m) => [...m, { role: "assistant", text: result.reply }]);
      setWidgetState(result.widgetState);
    } finally {
      setApprovalBusy(false);
    }
  }

  async function handleReset() {
    setLoading(true);
    await api.reset();
    setMessages([]);
    await bootstrap();
  }

  const mode = widgetState?.view || "health";

  return (
    <div className="h-screen w-screen flex flex-col bg-ink font-body">
      <header className="h-16 shrink-0 border-b border-line flex items-center justify-between px-6">
        <div className="flex items-center gap-2.5">
          <ShieldCheck className="text-brass" size={22} strokeWidth={1.75} />
          <div>
            <h1 className="font-display text-lg font-semibold text-paper leading-none">FinShield</h1>
            <p className="text-[10px] uppercase tracking-[0.18em] text-mist mt-1">Financial Resilience Copilot</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <span
            className={`text-[10px] uppercase tracking-wider px-2.5 py-1 rounded-full border ${
              mode === "crisis"
                ? "text-crisis border-crisis/40 bg-crisis/10"
                : "text-keep border-keep/30 bg-keep/10"
            }`}
          >
            {mode === "crisis" ? "Crisis Mode" : "Health View"}
          </span>
          <button
            onClick={handleReset}
            title="Reset demo"
            className="h-8 w-8 rounded-full border border-line flex items-center justify-center text-mist hover:text-paper hover:border-mist transition"
          >
            <RotateCcw size={14} />
          </button>
        </div>
      </header>

      <div className="flex-1 flex min-h-0">
        <div className="w-full max-w-[380px] shrink-0">
          <ChatPanel messages={messages} onSend={handleSend} loading={loading} />
        </div>
        <main className="flex-1 overflow-y-auto p-6 md:p-8">
          <Dashboard widgetState={widgetState} />
        </main>
      </div>

      <ApprovalModal
        pendingApproval={widgetState?.pendingApproval}
        onApprove={() => handleApproval(true)}
        onDeny={() => handleApproval(false)}
        busy={approvalBusy}
      />
    </div>
  );
}
