/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#0E1420",
        surface: "#161D2E",
        raised: "#1E2740",
        line: "#2A3348",
        paper: "#F1EEE6",
        mist: "#8B96AC",
        brass: "#C9A227",
        "brass-dim": "#8A701C",
        keep: "#4FAE7C",
        question: "#E0A93A",
        cancel: "#D9614F",
        crisis: "#B8483A",
      },
      fontFamily: {
        display: ["Fraunces", "serif"],
        body: ["Inter", "sans-serif"],
        mono: ["JetBrains Mono", "monospace"],
      },
      boxShadow: {
        vault: "0 0 0 1px rgba(201,162,39,0.15), 0 20px 50px -20px rgba(0,0,0,0.6)",
      },
      keyframes: {
        stampin: {
          "0%": { transform: "scale(2.2) rotate(-14deg)", opacity: "0" },
          "60%": { transform: "scale(0.94) rotate(-8deg)", opacity: "1" },
          "100%": { transform: "scale(1) rotate(-8deg)", opacity: "1" },
        },
        risein: {
          "0%": { transform: "translateY(8px)", opacity: "0" },
          "100%": { transform: "translateY(0)", opacity: "1" },
        },
      },
      animation: {
        stampin: "stampin 0.4s cubic-bezier(.2,.8,.3,1.2) both",
        risein: "risein 0.35s ease-out both",
      },
    },
  },
  plugins: [],
};
