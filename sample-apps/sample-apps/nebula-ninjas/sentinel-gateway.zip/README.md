# Sentinel Gateway 🛡️

> **An MCP Zero-Trust Gateway**: Real-Time Tool-Poisoning Detection & Cryptographic Provenance Ledger for Model Context Protocol (MCP) servers.

Built with **NitroStack SDK**, **TypeScript**, and **React Widgets**.

---

## 🌟 Overview

Every AI agent in an enterprise that calls an MCP tool routes through **Sentinel Gateway** instead of communicating directly with downstream MCP servers.

To the agent and AI client, Sentinel Gateway looks and behaves like a standard MCP server. Internally, it enforces zero-trust security:

1. **Discovery & Fingerprinting**: Intercepts tool definitions upon registration and pins their SHA-256 hashes (description + schema).
2. **Integrity Engine (Drift / Poisoning Detection)**: On every tool call, re-fetches and re-hashes the downstream tool description. Any mismatch blocks the call instantly *before* the model acts on poisoned metadata.
3. **RBAC Policy Engine**: Granular per-agent tool permissions with a default-deny security model.
4. **Injection Detection**: Heuristic scanning for prompt injection patterns, hidden HTML instructions, and exfiltration directives.
5. **Cryptographic Provenance Ledger**: An append-only, SHA-256 hash-chained audit log (`entry[n].hash = sha256(entry[n] + entry[n-1].hash)`). Any database tampering immediately breaks chain verification.
6. **Human-in-the-Loop Review Queue**: Flagged drift items and suspicious calls park in an interactive queue for one-click review and fingerprint re-pinning.

---

## 📐 Architecture

```
   Agent / Claude Client / AI Application
                     │
                     ▼ (Standard MCP Protocol)
┌─────────────────────────────────────────────────────────┐
│                    SENTINEL GATEWAY                     │
│                                                         │
│  ① Discovery & Fingerprint Layer                        │
│     • Intercepts tool-list responses from downstream   │
│     • Pins SHA-256(name + description + schema)         │
│                                                         │
│  ② Integrity Engine (Drift & Poisoning Detector)        │
│     • Re-verifies tool hash on EVERY invocation         │
│     • Blocks call if description has been poisoned      │
│                                                         │
│  ③ Policy Engine (RBAC)                                 │
│     • Per-agent permissions & parameter constraints     │
│     • Default-deny access model                         │
│                                                         │
│  ④ Injection Detector                                   │
│     • Scans for prompt injection & hidden directives    │
│                                                         │
│  ⑤ Cryptographic Provenance Ledger                      │
│     • Unforgeable SHA-256 hash-chained log              │
│     • Real-time chain verification                      │
│                                                         │
│  ⑥ Human Review Queue & Interactive Widgets             │
│     • Live feed, topology graph, review & attack panel  │
└─────────────────────────────────────────────────────────┘
                     │ (Only approved & verified calls pass)
                     ▼
  Downstream Internal MCP Servers (Filesystem, CRM, Email)
```

---

## 🖥️ Interactive UI Widgets

Sentinel Gateway provides 6 rich, interactive React widgets:

- `/live-feed`: Real-time scrolling feed of tool calls, statuses (`ALLOWED`, `BLOCKED`, `FLAGGED`), and short hashes.
- `/ledger-viewer`: Audit log viewer with 1-click **Verify Chain Integrity** button and hash linkage visualizer.
- `/review-queue`: Approval interface for flagged calls and tool drift items with side-by-side diff inspection.
- `/server-topology`: Network topology graph visualizing Caller Agents → Sentinel Gateway → MCP Servers & Tools.
- `/attack-demo`: Live Attack Simulator panel with 1-click triggers for staging tool-poisoning, RBAC violation, and ledger tampering attacks.
- `/dashboard-stats`: Security Operations Command dashboard showing total calls, threats blocked, and ledger health.

---

## 🚀 Quick Start

### Prerequisites
- Node.js >= 18.x
- npm

### 1. Installation
```bash
git clone https://github.com/your-org/sentinel-gateway.git
cd sentinel-gateway
npm install
```

### 2. Start Downstream Mock Servers
In a separate terminal window:
```bash
npm run mock-servers
```
Starts 3 mock MCP servers:
- 📁 Filesystem server: `http://localhost:3001`
- 👥 CRM server: `http://localhost:3002`
- 📧 Email server: `http://localhost:3003`

### 3. Start Sentinel Gateway
```bash
npm run dev
```
Sentinel Gateway runs on `http://localhost:3000`.

---

## 🧪 Testing & Demo Walkthrough

### 1. Initialize Demo Environment
In **NitroStudio** or via tool call:
- Call `setup_demo` — registers all 3 mock servers and fingerprints 9 tools.
- Call `setup_demo_policies` — sets up agent RBAC rules (`sales-bot`, `data-analyst`, `rogue-agent`).

### 2. Test Normal Proxy Call
Call `call_tool`:
```json
{
  "agentId": "sales-bot",
  "serverName": "crm-server",
  "toolName": "get_customer",
  "args": { "customerId": "cust-001" }
}
```
**Result**: `ALLOWED` — forwarded to downstream CRM server and logged in ledger.

### 3. Stage Tool Poisoning Attack 🚨
Call `run_attack` with `scenario: "tool_poisoning"` (or click the button in `/attack-demo` widget):
- Rewrites `send_email` description on email server to inject hidden BCC instructions.
- Triggers a call to `send_email`.
- **Result**: `BLOCKED` — integrity agent detects hash mismatch and halts execution. Item added to review queue.

### 4. Verify Ledger Integrity
- Call `verify_chain_integrity`: Returns `valid: true`.
- Call `run_attack` with `scenario: "ledger_tampering"` (mutates historical entry).
- Call `verify_chain_integrity`: Returns `valid: false` and highlights broken entry index.

---

## 📦 Tech Stack

- **Framework**: NitroStack SDK (`@nitrostack/core`, `@nitrostack/widgets`, `@nitrostack/cli`)
- **Language**: TypeScript (ES2022)
- **Cryptography**: Node.js `crypto` (SHA-256 hash chaining & fingerprinting)
- **Frontend Widgets**: Next.js 14, React 18, Tailwind CSS, Lucide React, Framer Motion

---

## 🔒 Security Posture & "Who Watches the Watcher?"

All configuration changes within Sentinel Gateway (policy updates, server registrations, fingerprint re-pinning, review approvals) pass through the **same hash-chained provenance ledger** as agent tool calls. There are no un-audited administrative back doors.
