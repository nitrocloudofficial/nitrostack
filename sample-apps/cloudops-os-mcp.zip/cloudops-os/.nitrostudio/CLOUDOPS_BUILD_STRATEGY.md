# CloudOps OS — 13-Hour Hackathon Build Strategy

## Executive Summary

**Goal:** Deploy a fully autonomous, multi-agent Terraform governance engine as NitroStack MCP servers with real-time reasoning, HCL mutation, and an interactive HITL console.

**Current State:** 70% complete
- ✅ NitroStack MCP server bootstrapped
- ✅ Terraform module with 2 tools (`analyze_terraform`, `finalize_terraform`)
- ✅ Interactive console widget (terraform-pr) with full HITL UI
- ✅ Python orchestrator skeleton + 4-agent registry
- ✅ Gemini 2.5 Flash + Groq LLM client (dual-provider)
- ✅ Local fallback rule engine (regex-based)

**Missing (10 hours):**
1. **HCL2 AST Parser** (2h) — Replace fragile regex with proper Terraform parsing
2. **LLM Agent Implementations** (2.5h) — Wire Gemini/Groq into 4 agents
3. **AWS Pricing API** (1.5h) — Live cost calculations
4. **Policy Validator** (1h) — SCP/region/CIDR/tag rules
5. **Smoke Tests** (1h) — End-to-end validation
6. **Typecheck + Dev Server** (1h) — Verify MCP connection
7. **Deployment Docs** (1h) — README + setup

---

## Architecture Overview

### MCP Server Topology

```
┌─────────────────────────────────────────────────────────────────┐
│                    NitroStack MCP Server                        │
│                    (src/index.ts, app.module.ts)                │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Terraform Module                             │
│              (src/modules/terraform/)                           │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Tool 1: analyze_terraform                              │   │
│  │ - Input: terraform_code (HCL), user_instructions       │   │
│  │ - Output: diagnostics[], costSummary, modifiedCode     │   │
│  │ - Calls: cloudops/main.py (Python orchestrator)        │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Tool 2: finalize_terraform                             │   │
│  │ - Input: terraform_code (approved), notify_slack       │   │
│  │ - Output: commitHash, deploymentLog, slackStatus       │   │
│  │ - Calls: Slack Webhook API (optional)                  │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│              Python Orchestrator (cloudops/main.py)             │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ CloudOpsOrchestrator                                    │   │
│  │ - Initializes LLM client (Groq → Gemini → None)        │   │
│  │ - Runs 4-agent pipeline sequentially                    │   │
│  │ - Aggregates diagnostics, costs, logs                   │   │
│  │ - Returns canonical JSON to NitroStack                  │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ WorkflowManager                                         │   │
│  │ - Executes: resource_agent → cost_agent →              │   │
│  │             policy_agent → release_agent               │   │
│  │ - Each agent reads/writes shared context               │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ 4 Specialized Agents (cloudops/agents/)                │   │
│  │                                                         │   │
│  │ 1. ResourceRoute Agent (FinOps)                        │   │
│  │    - Flags NAT Gateway overhead                        │   │
│  │    - Injects VPC Endpoints                             │   │
│  │    - Calculates $0.045/GB savings                      │   │
│  │                                                         │   │
│  │ 2. CostOptimization Agent                              │   │
│  │    - Rightsizes EC2 (m5.large → t3.medium)            │   │
│  │    - Upgrades storage (gp2 → gp3)                      │   │
│  │    - Suggests Spot/Scheduler policies                  │   │
│  │                                                         │   │
│  │ 3. PolicyGovernance Agent                              │   │
│  │    - Validates AWS regions (SCP)                       │   │
│  │    - Restricts ingress CIDRs (SOC2)                    │   │
│  │    - Injects compliance tags                           │   │
│  │                                                         │   │
│  │ 4. Release Agent                                       │   │
│  │    - Validates HCL syntax (terraform fmt/validate)     │   │
│  │    - Generates terraform plan output                   │   │
│  │    - Packages final execution state                    │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ LLM Client (cloudops/gemini/client.py)                 │   │
│  │ - Provider selection: Groq (primary) → Gemini (fallback)   │   │
│  │ - Rate limiting: 14 req/min                            │   │
│  │ - Retry handler: exponential backoff                   │   │
│  │ - JSON response parsing                                │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│              Interactive HITL Console Widget                    │
│         (src/widgets/app/terraform-pr/page.tsx)                │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ 4-Agent Pipeline Stepper                               │   │
│  │ - Visual progress: ⚙️ → 💰 → 🛡️ → 🚀                    │   │
│  │ - Live status badges (Processing, Ready, Standby)      │   │
│  │ - Glowing pulse animations                             │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Multi-Tab Code Viewer                                  │   │
│  │ - 📝 Code Diff (side-by-side original vs. optimized)   │   │
│  │ - 📥 Draft Input HCL                                   │   │
│  │ - 🔍 Audit Findings (diagnostics list)                 │   │
│  │ - 🚀 Dry Run Plan (terraform plan output)              │   │
│  │ - 📋 Reasoning Log (per-agent execution trace)         │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ XAI Reasoning Card (Flag → Explain → Diagnose → Resolve)   │   │
│  │ - Flagged anomaly (red snippet)                        │   │
│  │ - Explanation (why it matters)                         │   │
│  │ - Diagnosis (root cause)                               │   │
│  │ - Resolved code (green snippet)                        │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ FinOps Costing Ledger                                  │   │
│  │ - Monthly/Annual savings breakdown                     │   │
│  │ - Per-resource cost deltas                             │   │
│  │ - Strategic options (Spot, Scheduler)                  │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ HITL Action Panel                                      │   │
│  │ - Custom instruction override textarea                 │   │
│  │ - "Request Changes" button (re-runs pipeline)          │   │
│  │ - Slack notification checkbox                          │   │
│  │ - "Approve & Save Changes" button (finalizes)          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Success Display (Post-Merge)                           │   │
│  │ - Deployment log (terraform apply simulation)          │   │
│  │ - Slack notification preview (rich blocks)             │   │
│  │ - Commit hash reference                                │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Build Roadmap (10 Hours Remaining)

### Phase 1: HCL2 AST Parser (2 hours)

**Goal:** Replace fragile regex mutations with proper Terraform HCL2 parsing.

**Why:** Current regex-based approach breaks on:
- Multi-line blocks
- Nested structures
- Comments
- String interpolations

**Implementation:**
1. Use `hcl2` Python library (pip install hcl2)
2. Parse HCL → Python dict
3. Mutate dict (safe, type-aware)
4. Serialize back to HCL

**Files to create:**
- `cloudops/hcl_parser.py` — HCL2 parser + serializer
- `cloudops/hcl_mutator.py` — Safe mutation functions

**Key functions:**
```python
def parse_hcl(hcl_str: str) -> dict
def mutate_instance_type(hcl_dict: dict, old_type: str, new_type: str) -> dict
def mutate_volume_type(hcl_dict: dict, old_type: str, new_type: str) -> dict
def mutate_region(hcl_dict: dict, old_region: str, new_region: str) -> dict
def mutate_security_group_ingress(hcl_dict: dict, old_cidr: str, new_cidr: str) -> dict
def inject_tags(hcl_dict: dict, tags: dict) -> dict
def serialize_hcl(hcl_dict: dict) -> str
```

---

### Phase 2: LLM Agent Implementations (2.5 hours)

**Goal:** Wire Gemini 2.5 Flash + Groq into 4 agents with structured prompts.

**Current state:** Agents have stubs (api.py, prompt.py, parser.py) but no LLM calls.

**Implementation per agent:**

#### 2a. Resource & Route Agent (30 min)
- **Prompt:** "Analyze Terraform for network routing inefficiencies. Flag NAT Gateways, suggest VPC Endpoints."
- **LLM call:** Send HCL + prompt to Gemini/Groq
- **Parse response:** Extract diagnostics, cost items, modified HCL
- **Store:** In context manager

**File:** `cloudops/agents/resource_agent/prompt.py`
```python
SYSTEM_PROMPT = """You are the Resource & Route Optimization Agent (FinOps).
Analyze Terraform HCL for network topology inefficiencies:
1. Flag AWS NAT Gateways (hourly fee + $0.045/GB transit)
2. Suggest VPC Gateway Endpoints for AWS services (free)
3. Calculate monthly savings

Return JSON:
{
  "diagnostics": [{"id": "RTE-001", "severity": "INFO", ...}],
  "costItems": [{"resource": "...", "savings": 77.40, ...}],
  "modifiedCode": "..."
}"""
```

#### 2b. Cost Optimization Agent (30 min)
- **Prompt:** "Analyze Terraform for compute/storage inefficiencies. Rightsize EC2, upgrade storage."
- **LLM call:** Send HCL + prompt
- **Parse response:** Extract instance type recommendations, storage upgrades
- **Store:** In context manager

#### 2c. Policy & Governance Agent (30 min)
- **Prompt:** "Validate Terraform against SCP policies. Check regions, ingress CIDRs, tags."
- **LLM call:** Send HCL + policy rules + prompt
- **Parse response:** Extract policy violations, remediation
- **Store:** In context manager

#### 2d. Release Agent (30 min)
- **Prompt:** "Validate HCL syntax, generate terraform plan output."
- **LLM call:** Send HCL + prompt
- **Parse response:** Extract plan summary, validation status
- **Store:** In context manager

#### 2e. Parser implementations (30 min)
- Implement `parse_llm_response()` for each agent
- Extract JSON from LLM response
- Normalize to agent output schema
- Handle errors gracefully

---

### Phase 3: AWS Pricing API Integration (1.5 hours)

**Goal:** Replace hardcoded costs with live AWS Pricing API.

**Implementation:**
1. Use `boto3` (AWS SDK) or direct HTTP to AWS Pricing API
2. Query EC2 pricing (on-demand, spot, reserved)
3. Query EBS pricing (gp2 vs. gp3)
4. Query NAT Gateway pricing

**File:** `cloudops/aws_pricing.py`
```python
class AWSPricingClient:
    def get_ec2_price(self, instance_type: str, region: str) -> float
    def get_ebs_price(self, volume_type: str, size_gb: int, region: str) -> float
    def get_nat_gateway_price(self, region: str) -> float
    def get_spot_price(self, instance_type: str, region: str) -> float
```

**Integration points:**
- Resource agent: NAT Gateway pricing
- Cost agent: EC2 + EBS pricing
- Release agent: Aggregate costs

---

### Phase 4: Policy Validator (1 hour)

**Goal:** Build configurable SCP/policy validator.

**Implementation:**
1. Define policy rules (JSON config)
2. Validate HCL against rules
3. Generate remediation suggestions

**File:** `cloudops/policy_validator.py`
```python
class PolicyValidator:
    def __init__(self, policy_config: dict):
        self.allowed_regions = policy_config.get('allowed_regions', [])
        self.required_tags = policy_config.get('required_tags', {})
        self.restricted_ports = policy_config.get('restricted_ports', [])
    
    def validate(self, hcl_dict: dict) -> list[Diagnostic]
    def validate_region(self, region: str) -> bool
    def validate_ingress(self, ingress_rules: list) -> list[Diagnostic]
    def validate_tags(self, resource: dict) -> list[Diagnostic]
```

**Default policy config:**
```json
{
  "allowed_regions": ["us-east-1", "us-west-2", "eu-west-1"],
  "restricted_ports": [22, 3389],
  "required_tags": {
    "Environment": ["Production", "Staging", "Development"],
    "Compliance": ["SOC2-PCI", "HIPAA", "None"],
    "Owner": "string"
  }
}
```

---

### Phase 5: Smoke Tests (1 hour)

**Goal:** End-to-end validation: upload TF → analyze → export.

**Test cases:**
1. **Happy path:** Valid TF → analyze → get diagnostics + costs
2. **Override path:** Valid TF + custom instructions → re-analyze
3. **Finalize path:** Approved TF → finalize → get commit hash
4. **Error path:** Invalid TF → graceful error handling

**File:** `test_e2e.py`
```python
def test_analyze_terraform():
    # Upload sample TF
    # Call analyze_terraform tool
    # Assert diagnostics, costs, modified code
    
def test_custom_instructions():
    # Upload TF + custom instructions
    # Call analyze_terraform with overrides
    # Assert changes applied
    
def test_finalize():
    # Call finalize_terraform
    # Assert commit hash, deployment log
```

---

### Phase 6: Typecheck + Dev Server (1 hour)

**Goal:** Verify TypeScript compilation and MCP connection.

**Steps:**
1. Run `tsc --noEmit` → fix diagnostics
2. Start dev server: `npm run dev`
3. Verify MCP tools appear in Studio chat
4. Test widget renders with sample data

---

### Phase 7: Deployment Docs (1 hour)

**Goal:** Create README with setup instructions.

**Contents:**
1. Architecture overview
2. Prerequisites (Node.js, Python, API keys)
3. Installation steps
4. Environment variables (.env)
5. Running the server
6. Testing the MCP tools
7. Deploying to production

---

## Key Technical Decisions

### 1. **Dual-Provider LLM Strategy**
- **Primary:** Groq (faster, cheaper, 70B model)
- **Fallback:** Gemini 2.5 Flash (more capable, higher rate limits)
- **Fallback:** Local rule engine (no API required)

### 2. **HCL Mutation Strategy**
- **Parse:** HCL2 library (safe, type-aware)
- **Mutate:** Python dict operations
- **Serialize:** Back to HCL string

### 3. **Context Manager Pattern**
- **Namespaced store:** `"agent_name::key"` → value
- **Thread-safe:** RLock for concurrent access
- **Accumulative:** Each agent reads/writes shared state

### 4. **Widget State Management**
- **useWidgetState hook:** Persists across re-renders
- **Tabs:** Diff, Draft, Diagnostics, Plan, Logs
- **XAI card:** Flag → Explain → Diagnose → Resolve

### 5. **Error Handling**
- **Graceful degradation:** LLM → Local rules
- **Structured errors:** JSON with error field
- **Logging:** Per-agent execution trace

---

## Success Criteria

✅ **By end of 13-hour hackathon:**
1. All 4 agents wired to Gemini/Groq
2. HCL2 parser replaces regex
3. AWS Pricing API integrated
4. Policy validator working
5. Smoke tests passing
6. TypeScript clean
7. Dev server running
8. Widget rendering correctly
9. README complete
10. Ready for deployment

---

## Estimated Timeline

| Phase | Task | Duration | Status |
|-------|------|----------|--------|
| 1 | HCL2 AST Parser | 2h | ⏳ Pending |
| 2 | LLM Agent Implementations | 2.5h | ⏳ Pending |
| 3 | AWS Pricing API | 1.5h | ⏳ Pending |
| 4 | Policy Validator | 1h | ⏳ Pending |
| 5 | Smoke Tests | 1h | ⏳ Pending |
| 6 | Typecheck + Dev Server | 1h | ⏳ Pending |
| 7 | Deployment Docs | 1h | ⏳ Pending |
| **TOTAL** | | **10h** | ⏳ In Progress |

**Buffer:** 3 hours (for debugging, integration issues, final polish)

---

## Next Steps

1. **Implement HCL2 parser** (Phase 1)
2. **Wire LLM agents** (Phase 2)
3. **Integrate AWS Pricing** (Phase 3)
4. **Build policy validator** (Phase 4)
5. **Run smoke tests** (Phase 5)
6. **Typecheck + deploy** (Phase 6-7)

**Let's ship CloudOps OS! 🚀**
